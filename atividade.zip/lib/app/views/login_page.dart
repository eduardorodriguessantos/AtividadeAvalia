
import 'package:flutter/material.dart';
import '../viewmodels/login_viewmodel.dart';
import 'home_page.dart';
import 'signup_page.dart';

class LoginPage extends StatelessWidget {
  final emailController = TextEditingController();
  final senhaController = TextEditingController();
  final viewModel = LoginViewModel();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Login")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: emailController, decoration: InputDecoration(labelText: "Email")),
            TextField(controller: senhaController, decoration: InputDecoration(labelText: "Senha"), obscureText: true),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                bool sucesso = viewModel.login(emailController.text, senhaController.text);
                if (sucesso) {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => HomePage()));
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text("Login inválido")),
                  );
                }
              },
              child: Text("Entrar"),
            ),
            TextButton(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => SignupPage()));
              },
              child: Text("Criar conta"),
            )
          ],
        ),
      ),
    );
  }
}
