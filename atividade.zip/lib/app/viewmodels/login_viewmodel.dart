
import '../data/usuario_mock_store.dart';

class LoginViewModel {
  bool login(String email, String senha) {
    final user = UsuarioMockStore.autenticar(email, senha);
    return user != null;
  }
}
