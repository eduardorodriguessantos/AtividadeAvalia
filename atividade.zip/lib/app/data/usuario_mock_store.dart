
import '../models/usuario_model.dart';

class UsuarioMockStore {
  static List<UsuarioModel> usuarios = [];

  static void adicionarUsuario(UsuarioModel usuario) {
    usuarios.add(usuario);
  }

  static UsuarioModel? autenticar(String email, String senha) {
    try {
      return usuarios.firstWhere(
        (user) => user.email == email && user.senha == senha,
      );
    } catch (e) {
      return null;
    }
  }
}
